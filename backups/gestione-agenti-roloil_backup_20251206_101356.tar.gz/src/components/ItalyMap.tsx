import React, { useState, useCallback } from 'react';
import Map, { Source, Layer, MapStyle } from 'react-map-gl/maplibre';
import 'maplibre-gl/dist/maplibre-gl.css';

interface ItalyMapProps {
  className?: string;
}

interface MapStyle {
  id: string;
  name: string;
  url: string;
}

const mapStyles: MapStyle[] = [
  {
    id: 'streets',
    name: 'Strade',
    url: 'https://demotiles.maplibre.org/style.json'
  },
  {
    id: 'satellite',
    name: 'Satellite',
    url: 'https://api.maptiler.com/maps/hybrid/style.json?key=get_your_own_OpIi9ZULNHzrESv6T2Ju'
  },
  {
    id: 'terrain',
    name: 'Terreno',
    url: 'https://api.maptiler.com/maps/outdoor/style.json?key=get_your_own_OpIi9ZULNHzrESv6T2Ju'
  },
  {
    id: 'light',
    name: 'Chiaro',
    url: 'https://api.maptiler.com/maps/basic/style.json?key=get_your_own_OpIi9ZULNHzrESv6T2Ju'
  },
  {
    id: 'dark',
    name: 'Scuro',
    url: 'https://api.maptiler.com/maps/basic-dark/style.json?key=get_your_own_OpIi9ZULNHzrESv6T2Ju'
  }
];

// Coordinate dell'Italia per centrare la mappa
const ITALY_BOUNDS = {
  latitude: 41.8719,
  longitude: 12.5674,
  zoom: 5.5
};

// Dati GeoJSON dell'Italia (semplificati)
const italyGeoJSON = {
  type: 'FeatureCollection',
  features: [
    {
      type: 'Feature',
      properties: {
        name: 'Italia',
        color: '#FFD700' // Giallo
      },
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [6.6, 47.2],    // Nord-ovest
          [18.4, 47.2