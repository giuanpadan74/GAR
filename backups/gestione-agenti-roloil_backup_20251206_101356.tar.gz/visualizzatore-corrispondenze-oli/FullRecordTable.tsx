import React, { useState, useMemo } from 'react';
import { CorrespondenceRecord } from '../src/types/corrispondenze-new';

interface FullRecordTableProps {
  records: CorrespondenceRecord[];
  loading: boolean;
}

const FullRecordTable: React.FC<FullRecordTableProps> = ({ records, loading }) => {
  const [sortField, setSortField] = useState<keyof CorrespondenceRecord>('brand');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');

  // Dati ordinati e filtrati
  const sortedAndFilteredRecords = useMemo(() => {
    let filtered = records;

    // Filtra per termine di ricerca
